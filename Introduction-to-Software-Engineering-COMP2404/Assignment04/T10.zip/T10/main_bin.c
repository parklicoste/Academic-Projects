#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "person.h"

int fexists(char *fileName);

int main(int argc, char *argv[]) {

  struct personalInfo person;
  FILE *fid;
  int i;
  int rc;

// add coded


  // if the file does not exist print message

    if(fexists(argv[1]) == 0){
        printf("File %s does not exist\n", argv[1]);
        return 1;
    }else{
        printf("File %s exists\n", argv[1]);
    }

    // open the file
    fid = fopen(argv[1], "rb+");

//    printf("1 cur pos: %d\n", ftell(fid));

    rc = fread(&person, sizeof(struct personalInfo), 1, fid);
    if(rc == 1) printf("Record was read successfully\n");

    person.salary[0] = 47500;
    person.salary[1] = 40000;
    person.salary[2] = 23000;
    person.salary[3] = 51000;
    person.salary[4] = 37000;
    person.age = 36;

    printPerson(&person);

    fseek(fid, 2 * sizeof(struct personalInfo), SEEK_CUR);
    rc = fwrite(&person, sizeof(struct personalInfo), 1, fid);
    if(rc == 1) printf("Written Successfully\n");

    int currentPosition = ftell(fid);
    int recordNumber = (currentPosition)/sizeof(struct personalInfo);

    printf("\nRecord Number: %d\n\n", recordNumber);

    fseek(fid, -sizeof(struct personalInfo), SEEK_CUR);
    
    fread(&person, sizeof(struct personalInfo), 1, fid);
    printPerson(&person);
    fclose(fid);

  return 0;
}

/************************************************************************/
// Return whether the given file exists in the current directory.
// TODO: Complete this function.
int fexists(char *fileName)
{

    // add code 
    FILE *fp = NULL;
    int rc = 0;

    // open the file
    fp = fopen(fileName, "r");

    // determine the recturn code
    if(fp == NULL) rc = 0;
    else rc = 1;

    return(rc);
}
